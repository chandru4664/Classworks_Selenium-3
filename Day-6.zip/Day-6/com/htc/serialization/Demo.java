package com.htc.serialization;

//Java code for serialization and deserialization 
//of a Java object
import java.io.*;

class Demo implements java.io.Serializable
{
 
/**
	 * 
	 */
	private static final long serialVersionUID = 3744142648667299716L;
public int a;
 public String b;

 // Default constructor
 public Demo(int a, String b)
 {
     this.a = a;
     this.b = b;
 }

}