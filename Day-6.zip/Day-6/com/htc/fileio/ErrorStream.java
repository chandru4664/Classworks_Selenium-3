package com.htc.fileio;

public class ErrorStream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.err.println("error message");
	}

}
