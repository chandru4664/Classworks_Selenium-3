package com.htc.starter;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.testng.annotations.*;
import org.testng.asserts.Assertion;


public class FirstTestngSel {
	
	private static String baseurl="https://www.google.co.in/";
	private static WebDriver driver;
	

	@BeforeClass
	public static void initializeDriver(){
		 System.setProperty("webdriver.chrome.driver","D:\\AP-ONSITE-SELENIUM3-MATERIALS\\SELENIUMjars\\chrome\\chromedriver.exe");
		driver = new ChromeDriver();
		//driver=new HtmlUnitDriver();
		 driver.get(baseurl);
		 //driver.navigate().to(baseurl);
	}
  @SuppressWarnings("deprecation")
@Test
  public void verifyHomePAge() {
	  
	  String expectedTitle="Google";
	  String actualTitle=driver.getTitle();
      assertEquals(expectedTitle, actualTitle);
	  
  }
  
  @AfterClass
  public static void endTest()
  {
	  driver.quit();
	  //driver.close();
	 
	 
	  
  }
}
