package com.htc.junit;

public class MyClass {

	public int multiply(int a,int b){
		return a*b;
		
	}
}
