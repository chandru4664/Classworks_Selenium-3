package com.htc.java;

public class AppClass {
	public int sum(int a, int b) {
	 int s;
	  s=a+b;
	 return s;
	 }
	public boolean statusReturn(){
	Boolean statusFlag=true;
		return statusFlag;
	}
}
