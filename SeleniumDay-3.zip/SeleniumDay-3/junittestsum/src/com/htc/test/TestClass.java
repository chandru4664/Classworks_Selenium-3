package com.htc.test;

import static org.junit.Assert.assertEquals;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;

import com.htc.java.AppClass;

public class TestClass {
	 static AppClass obj;
	@BeforeAll
	void testbefoerAll() {
		System.out.println("Before all ");
	}
	 
	@BeforeClass
	  public static void init(){ 
		System.out.println("Inside before class.Object created");
		obj=new AppClass();
	     	   }
	@Before 
	 public void simplyBefore(){
		System.out.println("Before each test");
		}
	@After 
	public void simplyAfter(){
		System.out.println("After each test");
		}
	
     @Test(timeout=10)//timeout in milliseconds
	public  void  sumtest(){
    	 System.out.println("Inside first Test method");	 
	  int expected_result  =7;
	  int actual_result;
	  actual_result =obj.sum(3,4);
	  //throw new NullPointerException();
	   assertEquals(expected_result,actual_result,"Not match");
	
	   }
     @Test
     public void statusTest()
     {    System.out.println("Inside second Test method");
    	 boolean actualresult=obj.statusReturn();
    	 assertTrue(actualresult);
    	 
     }
     @AfterClass
	public static void teardown()
	{
		System.out.println("Memory cleared. resources deallocated. Database connection ended");
	}
}
