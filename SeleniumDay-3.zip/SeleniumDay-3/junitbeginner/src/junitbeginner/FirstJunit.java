package junitbeginner;

import java.util.Scanner;

import org.junit.Test;

public class FirstJunit {
@Test(timeout=500)
 public  void method1()
 {
	 System.out.println("in first test method....");
	 
 }
 @Test
 public static void method2() {
	 System.out.println("in second test method....");
	 //throw new NullPointerException(); 
     
     }
}
