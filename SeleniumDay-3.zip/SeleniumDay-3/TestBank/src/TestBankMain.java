import com.htc.bankapp.dto.Bank;

public class TestBankMain extends Bank{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
TestBankMain obj=new TestBankMain();
      obj.getBankAccounts();
	}

}
