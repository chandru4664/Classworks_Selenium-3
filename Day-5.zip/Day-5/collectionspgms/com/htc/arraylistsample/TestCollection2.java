package com.htc.arraylistsample;

import java.util.ArrayList;
//Iterating using for each loop.
class TestCollection2{  
	 public static void main(String args[]){  
	  ArrayList<String> al=new ArrayList<String>();  
	  al.add("Ravi");  
	  al.add("Vijay");  
	  al.add("Ravi");  
	  al.add("Ajay");  
	  for(String obj:al)  
	    System.out.println(obj);  
	  ArrayList<String> alnew=new ArrayList<String>(al); //using parameterised constructor to copy a collection
	  for(String obj:alnew)  
		    System.out.println(obj); 
	 }  
	}  