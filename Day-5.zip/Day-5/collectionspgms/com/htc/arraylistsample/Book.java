package com.htc.arraylistsample;

public class Book {
	  
		int id;  //default types.accsessible in same pkg.
		String name,author,publisher;  
		int quantity;  
		//parameterised constructor
		public Book(int id, String name, String author, String publisher, int quantity) {  
		    this.id = id;  
		    this.name = name;  
		    this.author = author;  
		    this.publisher = publisher;  
		    this.quantity = quantity;  
		}  
}
