package com.htc.Built_in_Exception;

//Java program to demonstrate NullPointerException
class NullPointer_Demo
{
  public static void main(String args[])
  {
      try {
          String a =null; //null value
          System.out.println(a.charAt(0));
      } catch(NullPointerException e) {
          System.out.println("NullPointerException..");
      }
      System.out.println("back to normal");
  }
}