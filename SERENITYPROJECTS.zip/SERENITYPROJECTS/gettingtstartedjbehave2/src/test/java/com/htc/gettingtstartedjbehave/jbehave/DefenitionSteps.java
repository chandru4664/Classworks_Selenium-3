package com.htc.gettingtstartedjbehave.jbehave;
import net.thucydides.core.annotations.Steps;

import org.jbehave.core.annotations.Aliases;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;


import com.htc.gettingtstartedjbehave.steps.Mysteps;

public class DefenitionSteps {
/*
	 @Steps
	    Mysteps endUser;
	
	 @Given("A store")
	public void givenAStore() {
	 endUser.createstore();
	}

	@Given("An item with $name and $price")
	public void givenAnItemWithnameAndprice(@Named("name")String item,@Named("price")double price) {
		endUser.newitem(item,price);
	}

	
	 @When("Item price does not exceed $pricelimit") 
    @Aliases(values={"Item price is less than $pricelimit",
    "Item price is bound to to $pricelimit"}) 
	public void whenItemPriceDoesNotExceedpricelimit(@Named("pricelimit")Double limit) {
		 endUser.checkmaxpricelimit(limit);
	}

	@Then("Item should be added to the Store")
	public void thenItemShouldBeAddedToTheStore() {
		
	     endUser.addtostore();
	}
*/
}
