package com.htc.gettingtstartedjbehave.pages;
import java.util.*;

public class Store {
	private Item obj;
	public Store() {
		// TODO Auto-generated constructor stub
	}
	private List<Item> itemlist=new ArrayList<Item>();
	
	public boolean additem(Item o){   
		boolean addstatus=false;
	 	if(o.checkprice()==true) 
	 		addstatus=itemlist.add(o);
	 	return addstatus;}
}
