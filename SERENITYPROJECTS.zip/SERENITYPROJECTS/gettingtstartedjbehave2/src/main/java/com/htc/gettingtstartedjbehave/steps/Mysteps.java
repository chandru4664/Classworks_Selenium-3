package com.htc.gettingtstartedjbehave.steps;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.annotations.Aliases;
import org.junit.Assert;

import com.htc.gettingtstartedjbehave.pages.Item;
import com.htc.gettingtstartedjbehave.pages.Store;

import net.thucydides.core.annotations.Step;

import org.jbehave.core.steps.Steps;

public class Mysteps extends Steps {
	 private Item o;
	 private Store obj;
	 
	   @Step
	 public void createstore() {
		 obj=new Store();
	 }
	 
	   @Step
	 public void newitem(String item,double price){
		o=new Item(item,price);
	}
	   
	   @Step
     public void checkmaxpricelimit(double pricelimit) {
    	 boolean checkmax=false;
    	 o.setmaxprice(pricelimit);
    	 checkmax=o.checkprice();
    	 Assert.assertTrue(checkmax);
     }
     
     @Step
     public void addtostore() {
    	boolean addstatus=false;
    	addstatus= obj.additem(o);
    	Assert.assertTrue(addstatus);
     }
     
}