package com.htc.gettingtstartedjbehave.pages;

public class Item{
	/*POJO Class*/
     private String itemname="";
     private double price=0.0;
     private double pricelimit=1000.00;
	public Item() {
		// TODO Auto-generated constructor stub
	}
	public Item(String item,double price) {
		// TODO Auto-generated constructor stub
	super();
	this.itemname=item;
	this.price=price;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getPricelimit() {
		return pricelimit;
	}
	public void setPricelimit(double pricelimit) {
		this.pricelimit = pricelimit;
	}
	public void setmaxprice(double maxprice)
	{
		this.pricelimit=maxprice;
	}
	public boolean checkprice() {
		 boolean checkstatus=true;
		 if(this.price>this.pricelimit) { 
			System.out.println("Price limit exceeded");
			checkstatus =false;
			}
		
	return checkstatus;}
		  
	
}
