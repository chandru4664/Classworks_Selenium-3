package com.htc.selenium1;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.htc.selenium.drivers.WebDriversFactory;

public class PG3 {
    public static void main(String[] args) {
    	
    	WebDriver driver =WebDriversFactory.getWebdriver();
    	
        driver.get("http://www.popuptest.com/popuptest2.html");
        //driver.close();//only the current window will close.
       driver.quit();  // using QUIT all windows will close
    }
}