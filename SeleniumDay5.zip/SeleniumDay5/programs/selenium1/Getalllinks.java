package com.htc.selenium1;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.htc.selenium.drivers.WebDriversFactory;

public class Getalllinks {
	public static void main(String[] args) {
		   
	      
	    	WebDriver driver = WebDriversFactory.getWebdriver();
	      driver.navigate().to("http://www.calculator.net");
	    ArrayList<WebElement> links = (ArrayList<WebElement>) driver.findElements(By.tagName("a"));
	      System.out.println("Number of Links in the Page is " + links.size());
	      
	      for (WebElement o:links) {
	         System.out.println("Name of Link# " +  o.getText());
	      }
	   driver.quit();}

}
