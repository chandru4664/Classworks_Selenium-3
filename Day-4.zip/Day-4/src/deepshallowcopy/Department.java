package com.htc.deepshallowcopy;

public class Department implements Cloneable //remove implements to test shallow copy
{
    private int id;
    private String name;
 
    public Department(int id, String name)
    {
        this.id = id;
        this.name = name;
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	//Defined clone method in Department class for Deep cloning. 
	@Override//comment to check shallow copy
	protected Object clone() throws CloneNotSupportedException {
	    return super.clone();
	}
}