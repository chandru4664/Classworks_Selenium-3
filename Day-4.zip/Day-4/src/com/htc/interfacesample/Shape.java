package com.htc.interfacesample;

//Java program to illustrate the
//concept of interface 

interface Shape
{
 // abstract method
 void draw();
 double area();
}
