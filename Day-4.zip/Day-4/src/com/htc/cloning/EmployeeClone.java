package com.htc.cloning;


	class EmployeeClone implements Cloneable {

		 private String name;
		 private String designation;
        
		 public EmployeeClone() {
		 this.setDesignation("Programmer");
		 }
		 public String getDesignation() {
		 return designation;
		 }

		 public void setDesignation(String designation) {
		 this.designation = designation;
		 }

		 public String getName() {
		 return name;
		 }

		 public void setName(String name) {
		 this.name = name;
		 }

		 public Object clone() throws CloneNotSupportedException {
		 
		/* EmployeeClone copyObj = new EmployeeClone(); 
		 copyObj.setDesignation(this.designation);
		 copyObj.setName(this.name);
		 return copyObj;
		 */
		 return super.clone();   
		 }
		}


