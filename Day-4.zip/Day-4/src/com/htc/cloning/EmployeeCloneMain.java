package com.htc.cloning;

public class EmployeeCloneMain {
	public static void main(String arg[]){
		 EmployeeClone original = new EmployeeClone();
		 original .setName("Jamie Zawinski");
		 original.setDesignation("Programmer");
		 try {
			EmployeeClone cloned = (EmployeeClone) original.clone(); //Deep Copy
			// EmployeeClone cloned =  original;//check shallow copy
			 //change the cloned object alone
			 cloned.setName("Sayooj");
			 cloned.setDesignation("Trainer");
		 		 
		//print original.in deep copy original remains unchanged
		 System.out.println(original.getName());
		 System.out.println(original.getDesignation());
		
		 } catch (Exception cnse) {
		 System.out.println("Cloneable should be implemented. " + cnse );
		 }
		 }
}
