package steps;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.steps.Steps;
import org.junit.Assert;

import core.Bmicalculator;
public class MySteps extends Steps {
	private Bmicalculator o;
	@Given("a body mass index calculator")
	
	public void givenABodyMassIndexCalculator(){
		  o=new Bmicalculator();
	}
	

	@When("a patient's is with mass $mass and height $height")
	
	public void testcheckbmi(@Named("mass")float weight,@Named("height") float height){
		 o.checkbmi(weight,height);
	}
	
	@Then("bmi result is $result")
	public void checkresult(@Named("result")String expectedresult){
		String actualresult=o.result();
		Assert.assertEquals(expectedresult,actualresult);
		 
	}
}