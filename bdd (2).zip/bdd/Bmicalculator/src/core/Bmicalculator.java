package core;

public class Bmicalculator  {

private float height,weight;
private String res;
public  Bmicalculator()
{this.res=null;}
public float getHeight() {
	return height;
}
public void setHeight(float height) {
	this.height = height;
}
public float getWeight() {
	return weight;
}
public void setWeight(float weight) {
	this.weight = weight;
}

public void checkbmi(float weight,float height)
	{
	
	Float bmi;
	this.weight=weight;
	this.height=height;
	bmi = (weight) / (height * height);
	
	if(bmi<=18.5)
		res="Underweight";
	else if(bmi>18.5&&bmi<24.9)
		res="Normal";
	else if(bmi>=25&&bmi<=29.9)
		res="Overweight";
	
	}

public String result()
{
	return this.res;
	}
}
