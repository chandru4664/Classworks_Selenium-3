package com.htc.polymorphism;

public interface Shape {
	int a=0;//default final variables
	public  void draw();//declarartion
	//all methods in an interface are by default abstaract
}
