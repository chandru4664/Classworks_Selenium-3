package com.htc.polymorphism;

public class CircleOverride implements Shape {
    /*Runtime polymorphism/dynamic polymorphism(method overiding)*/
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("From CircleOverride.Drawing Circle");
		
	}
	
}
