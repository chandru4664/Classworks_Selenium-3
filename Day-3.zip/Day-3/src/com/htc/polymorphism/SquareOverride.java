package com.htc.polymorphism;

public class SquareOverride implements Shape{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("From SquareOverride. Drawing Square");
	}

}
