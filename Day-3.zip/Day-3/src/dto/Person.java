package dto;

public class Person {
	private String name;
	private int SSN;
	private long phone;
	private char gender;
	private String address;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSSN() {
		return SSN;
	}
	public Person(String name, int SSN, long phone, char gender, String address) {
		//super();
		this.name = name;
		this.SSN = SSN;
		this.phone = phone;
		this.gender = gender;
		this.address = address;
	}
	public void setSSN(int sSN) {
		this.SSN = sSN;
	}
	public Person() {
		//super();
		this.name = "Hary";
		this.SSN = 111;
		this.phone = 78024804;
		this.gender = 'm';
		this.address = "gdjdgd 2nd Street";
	}
	
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", SSN=" + SSN + ", phone=" + phone + ", gender=" + gender + ", address="
				+ address + "]";
	}
	

}
