package main;

import dto.Person;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Person obj=new Person();//Default constructor
     obj.setName("Tom");
     System.out.println(obj.getName());
	System.out.println(obj);
	Person obj1=new Person("Sam",222,749477497,'m',"hdkhakhdkah");
	//Parameterized constructor constructor
	System.out.println(obj1);//from toString method
	}

}
