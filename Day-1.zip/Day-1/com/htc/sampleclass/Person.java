package com.htc.sampleclass;

 class Person {
   private String name;
    private int age;
    private char gender;
    private String Address;
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return Address;
	}
	/**
	 * @param name
	 * @param age
	 * @param gender
	 * @param string
	 * @param job
	 * @param bloodgroup
	 */
	public Person(String name, int age, char gender, String string, String job, String bloodgroup) {
		super();
		this.name = name;
		this.age = age;
		this.gender = gender;
		Address = string;
		Job = job;
		this.bloodgroup = bloodgroup;
	}
	public Person() {
		// TODO Auto-generated constructor stub
		this.name="Noname";
		this.age=0;
		this.gender='n';
		this.Address="Noaddress";
		this.Job="Nojob";
		this.bloodgroup="nogroup";
		
	}
	public void setAddress(String address) {
		Address = address;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", gender=" + gender + ", Address=" + Address + ", Job=" + Job
				+ ", bloodgroup=" + bloodgroup + "]";
	}
	public String getJob() {
		return Job;
	}
	public void setJob(String job) {
		Job = job;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	private String Job;
    private String bloodgroup;
}
