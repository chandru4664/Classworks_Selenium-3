package com.htc.selenium.drivers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriversFactory {
	public static WebDriver getWebdriver() {
		 System.setProperty("webdriver.chrome.driver","D:\\AP-ONSITE-SELENIUM3-MATERIALS\\SELENIUMjars\\chrome\\chromedriver.exe");
	      WebDriver driver = new ChromeDriver();
	      return driver;
	}

}
